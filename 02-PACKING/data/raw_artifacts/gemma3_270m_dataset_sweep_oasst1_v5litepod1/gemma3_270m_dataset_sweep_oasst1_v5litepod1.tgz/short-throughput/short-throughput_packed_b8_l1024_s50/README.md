# Gemma3 Packing Training Benchmark

This run compares ordinary fixed-length Tunix SFT batches against packed batches using Default CE only.

- Dataset: `oasst1-en-assistant-gemma3-it`
- Source: OpenAssistant/oasst1 English assistant replies with immediate prompter parent as prompt, Gemma3 IT wrapper, target-only loss
- Model: `google/gemma-3-270m-it`
- Tokenizer source: `sentencepiece`

![training_comparison](training_comparison.png)

## Summary

| Variant | Steps | Batch | Max length | Fit examples | Rows/batches | Final loss | Eval loss | BLEU | chrF | Step time | Valid tok/s | Loss tok/s | Packing density |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| packed | 50 | 8 | 1024 | 5000 | 146 | 1.6909 | nan | nan | nan | 0.119s | 68874 | 59789 | 99.9% |
