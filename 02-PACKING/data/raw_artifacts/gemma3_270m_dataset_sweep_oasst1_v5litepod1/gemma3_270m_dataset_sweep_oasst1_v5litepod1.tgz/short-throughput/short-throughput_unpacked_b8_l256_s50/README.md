# Gemma3 Packing Training Benchmark

This run compares ordinary fixed-length Tunix SFT batches against packed batches using Default CE only.

- Dataset: `oasst1-en-assistant-gemma3-it`
- Source: OpenAssistant/oasst1 English assistant replies with immediate prompter parent as prompt, Gemma3 IT wrapper, target-only loss
- Model: `google/gemma-3-270m-it`
- Tokenizer source: `sentencepiece`

![training_comparison](training_comparison.png)

## Summary

| Variant | Steps | Batch | Max length | Fit examples | Rows/batches | Final loss | Eval loss | BLEU | chrF | Step time | Valid tok/s | Loss tok/s | Packing density |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| unpacked | 50 | 8 | 256 | 5000 | 625 | 2.8171 | nan | nan | nan | 0.030s | 44151 | 34025 | 68.5% |
