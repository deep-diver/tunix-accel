# Gemma3 Packing Training Benchmark

This run compares ordinary fixed-length Tunix SFT batches against packed batches using Default CE only.

- Dataset: `synthetic-en-fr-shaped`
- Source: Deterministic synthetic EN-FR shaped text, Tunix Gemma prompt wrapper, target-only loss mask, target EOS
- Model: `google/gemma-3-1b-it`
- Tokenizer source: `sentencepiece`

![training_comparison](training_comparison.png)

## Summary

| Variant | Steps | Batch | Max length | Fit examples | Rows/batches | Final loss | Eval loss | BLEU | chrF | Step time | Valid tok/s | Loss tok/s | Packing density |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| unpacked | 4 | 16 | 512 | 1024 | 64 | 0.5769 | nan | nan | nan | 0.634s | 2801 | 1312 | 22.0% |
